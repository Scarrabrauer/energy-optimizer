# Energy Optimizer — PV + Wärmepumpe

Statische Web-App mit Dark Mode. Grundlage: die am 7. Oktober 2026 korrigierte Excel-Wirtschaftlichkeitsrechnung. Keine Installation, kein Build, keine externen Bibliotheken oder Dienste.

## Starten

Alle Dateien zusammen entpacken und index.html im Browser öffnen. Einstellungen werden lokal gespeichert, soweit der Browser das zulässt. Für Hosting oder lokale Vorschau bleiben alle Dateien im gleichen Ordner.

## GitHub Pages

1. Die Inhalte dieses Ordners in den Root eines GitHub-Repositories laden: index.html, app.js, styles.css, dark.css und .nojekyll. README.md kann mit hochgeladen werden.
2. Im Repository unter Settings → Pages die Veröffentlichung aus einem Branch wählen.
3. Branch main und Ordner / (root) einstellen. Die dort angezeigte Pages-Adresse öffnet die App.

Alle Asset-Pfade sind relativ. Die App funktioniert auch unter einer Repository-Unteradresse. Kein Backend, keine Schlüssel und keine Laufzeit-Abhängigkeiten erforderlich.

## Funktionen

- Dashboard mit Gesamt-/Nettoinvestition, Amortisation und 10-Jahres-Saldo
- Vier Szenarien: Konservativ, Basis, Optimistisch, Manuell
- Vergleich der drei vorgegebenen Szenarien mit aktuellen Projekt- und Verbrauchsparametern
- Kumulierte Wirtschaftlichkeit, jährlicher Nettonutzen, PV-Verteilung und Nutzenblöcke als SVG-Grafiken
- 5-/10-Jahres-Auswertung und Jahres-Cashflow mit separaten Einsparungen, Einspeisung, Mieterstrom, Steuern, Zuschüssen und laufenden Kosten
- Tageszeit-Priorisierung und farbige Matrix aus dem Excel-Modell
- Editierbare Parameter, lokale Speicherung, Rücksetzen und JSON-Export als Datei oder Zwischenablage
- Responsive Oberfläche mit horizontal scrollbaren Diagrammen/Tabellen auf kleinen Displays

## Rechenmodell

Zehn Jahresperioden, keine Abzinsung. PV-Ertrag nimmt jährlich entsprechend der Degradation ab. Eigener PV-Verbrauch und Mieterstrom werden durch Bedarf, Deckungsquote und verfügbaren PV-Ertrag begrenzt. Eigene Nutzung wird vor Mieterstrom zugeordnet. Rest-PV wird eingespeist.

Baseline: Haushalts-/Wallboxstrom, bisheriger Gasverbrauch, Grundpreise und Gaswartung. Projekt: verbleibender Netzstrom plus Strom-Grundpreis. Die Differenz ist die direkte Einsparung. WP-/PV-Wartung und Abrechnung werden gesondert abgezogen. Der Strom-Grundpreis bleibt im Projekt bestehen und fällt deshalb aus der Einsparungsdifferenz heraus.

Förderung wird einmalig in Jahr 1 gebucht. Nettoinvestition dient nur der Anzeige; der Cashflow startet mit der Bruttoinvestition und zählt Zuschüsse somit nur einmal. PV-Umsatzsteuer ist rein informativ. Steuerannahmen übernehmen die Excel-Planwerte, ohne aktuelle Anspruchsprüfung.

V+V: WP-Kosten × vermieteter Flächenanteil abzüglich zugeordnetem KfW-Grundzuschuss, verteilt über 2–5 Jahre. §35a: PV-Arbeitskosten × selbstgenutzter Anteil × 20 %, begrenzt auf 1.200 €, optional deaktivierbar.

Amortisation ist der erste Übergang des kumulierten Saldos auf mindestens null. Der Übergang innerhalb eines Jahres wird linear auf Monate interpoliert. Ohne Übergang im Zehnjahreszeitraum wird „> 10 Jahre“ angezeigt. Es handelt sich um eine Jahresmodell-Näherung, insbesondere bei einmaligen Rückflüssen in Jahr 1.

## Verbrauchsstrategie und Grenzen

Die Strategiemodi verändern die Deckungsquoten anhand der Excel-Faktoren: Standard 0,92 / 0,95, Optimal 1 / 1, Max. Autarkie 1,04 / 1,03 (eigen / Mieter). Eigene Deckung maximal 90 %, Mieter maximal 100 %.

Batteriegröße und SOC-Ziele sind Betriebsvorgaben. Sie ändern im Jahresmodell nicht automatisch den Cashflow. Zusätzliche Speicherkosten, Stundenprofile, Speicherverluste, reale Ladezustände und saisonale Wetterdaten sind nicht modelliert. Warmwasser ist im WP-Verbrauch enthalten und wird nicht zusätzlich gerechnet. Finanzierung ist nicht Teil der App. Prioritäten sind Betriebsempfehlungen, keine berechneten Stromflüsse oder automatische Gerätesteuerung. Für 23–24 Uhr gilt der Nachtmodus.

## Korrigierte Excel-Bezüge

- Effektive Mieterstromdeckung in Verbrauchsstrategie!G10 ergänzt; abhängige Formeln entsprechend verbunden.
- Steuer_VuV!B9 verwendet Eingaben!B22 (vermieteter Flächenanteil).
- Steuer_VuV!B15 verwendet Eingaben!B23 (selbstgenutzter Flächenanteil).

## Prüfung

Basisszenario: Investition 70.839 €, modellierte Zuschüsse 14.900 €, Nettoinvestition 55.939 €, Saldo nach fünf Jahren −25.237,26 €, nach zehn Jahren +3.576,18 €, Amortisation 9 Jahre 5 Monate.

Browser-Prüfung in Microsoft Edge: alle Szenarien, manuelle Eingaben, lokale Speicherung, Rücksetzen, Tageszeiten, SOC, JSON-Download, Nullertrag, ungültige Eingabe und Smartphone-Layout. Die Simulation wurde mit den Jahreswerten der korrigierten Excel abgeglichen. Kein Live-Deployment auf GitHub durchgeführt.

## Haus & Energie — Erweiterung

Neuer Bereich mit fünf geführten Frageschritten, 31 editierbaren Angaben, Quellenkennzeichnung und offenen Prüfpunkten. Startwerte: 281 m² Wohnfläche, 400,62 m² Gebäudenutzfläche, 1.400 m² Grundstück, Baujahr 2007, Kaltmiete 990 €/Monat, Gas 26.530,69 kWh/Jahr, drei Raummeter Buche. Planungsdaten aus dem Wärmeschutznachweis werden von tatsächlicher Anlagentechnik unterschieden.

Gas wird für die Heizenergiekennzahl mit 0,9 auf Heizwertbasis umgerechnet. Nutzwärme = Gas-Heizwert × Gasnutzungsgrad + Holz-Heizwert × Ofennutzungsgrad. WP-Strom = verbleibende Nutzwärme nach künftiger Holznutzung / Jahresarbeitszahl. PV-Deckung betrifft nur den geschätzten WP-Netzstrom, nicht die ungesicherte Energieausweisklasse. Verbrauchsnäherung ohne normgerechten Ausweis, ohne technischen Hilfsstrom und ohne gesicherte Wetterbereinigung. Kosten der historischen Gasrechnung sind Information, kein aktueller Tarif.

Hauswert: Gesamtwohnfläche × Vergleichspreis inklusive Grundstück × begründete Anpassung minus Reparaturen. Optional kann ein eigener aktueller Gesamtwert verwendet werden. Startpreis 3.732 €/m² aus Mannheims veröffentlichten EFH-Verkäufen 2025; keine spezifische Scharhof-Bewertung. Startkorridor ±30 %, frei veränderbare Modellunsicherheit, kein statistisches Konfidenzintervall. Der Grundstückswert und die Miete werden nicht nochmals addiert. Der Bodenrichtwert ist nur ein separater Plausibilitätsvergleich. Qualitative Antworten zeigen Prüfbedarf; sie erzeugen keine empirisch unbelegten automatischen Aufschläge. Szenarien 3/5/7 % bleiben separate Planannahmen und fließen nicht in den Energie-Cashflow.

Hausdaten werden separat lokal gespeichert und über die bestehenden JSON-Exportknöpfe mit exportiert. Der bewusste Übernahmeknopf aktualisiert Gas- und WP-Verbrauch der bestehenden Wirtschaftlichkeitsrechnung. Deren übrige Excel-Startwerte bleiben erhalten.

Für Veröffentlichung zusätzlich property.js hochladen. Vollständiges Paket: index.html, app.js, property.js, styles.css, dark.css, .nojekyll, README.md. Die vorausgefüllten Haus- und Mietdaten sind bei öffentlicher Veröffentlichung ebenfalls öffentlich; Originalrechnungen und personenbezogene Identifikatoren sind nicht enthalten.

Geprüft: JavaScript-Syntax, Browseranzeige, Frageschritte, Änderung der JAZ mit Neuberechnung, Speicherung nach Neuladen, Übernahme des Verbrauchs in Wirtschaftlichkeit. Keine Veröffentlichung auf GitHub durchgeführt.

## Angebotsprofile — Heidelberg Solar (10. Oktober 2026)

Im Bereich Simulation oben ein Angebot auswählen, dessen Daten prüfen und »Profilwerte übernehmen« anklicken. Die Auswahl allein verändert keine Rechenwerte. Heidelberg setzt PV-Kosten, Leistung, Jahresertrag, Verbrauchsbasis, Speichergröße und Mieterstrom-Annahmen; WP-Kosten und bestehende Tarif-/Förder-/Steuerwerte bleiben erhalten. Die aktive Konfiguration wird Manuell. Alle Zahlen können danach wie bisher angepasst werden; andere Szenarien ersetzen weiterhin ihre bisherigen Szenarioannahmen, einschließlich Ertrag und Mieterdeckung. Die Anbieterreferenzen bleiben unverändert und deutlich getrennt.

Hardware: 24,96 kWp, 52 AIKO A480-MCE54Db (40 Süd, 12 Carport), SigenStor EC 25.0 TP, zwei BAT 10.0, 17,52 kWh nutzbar / 18,1 kWh in PV*SOL, Gateway HomeProTP. Angebotspreis 30.839 €. Anbieterreferenzen: 28.429 kWh Ertrag, 15.020 kWh Einspeisung, 72,2 % Autarkie, 47,1 % Eigenverbrauch, 86 Monate PV-Amortisation ohne zusätzlich angesetzten Mieterstromerlös. Grundlage sind die vom Eigentümer übermittelten Werte, keine erneute Prüfung der ursprünglichen Anlagen.

Das Jahresmodell wird nicht künstlich auf diese Ergebnisse kalibriert: PV*SOL hat andere zeitliche Profile und EV-Ladeverluste. 3.000 kWh EV bleiben Fahrenergie-Annahme; reale Ladeenergie kann größer sein. Unsere Amortisation betrifft PV plus WP, inklusive Gasersatz, Förderung und Steuern. Daher ist sie nicht direkt mit der PV-Amortisation des Anbieters vergleichbar.

Heidelberg startet mit ausgeschaltetem §42b-Verkauf. Bei Aktivierung: 3.500 kWh Mietbedarf × 70 % = 2.450 kWh, 0,22 €/kWh = 539 € brutto in Jahr 1 bei Optimal und ausreichendem PV-Ertrag. Keine pauschale zusätzliche 539-€-Buchung. Miet-kWh gehören nicht zum eigenen, mit Bezugspreis bewerteten Verbrauch; sie reduzieren die Einspeisung. Beispiel Mehrnutzen gegenüber Verkauf aus: 539 € minus 173,46 € entgangene Einspeisung minus 180 € Abrechnung = 185,54 €/Jahr. Degradation, Strategie und manuelle Parameter verändern spätere Werte. Ohne Verkauf ordnet dieses Jahresmodell der Mietwohnung keinen PV-Strom zu; es bildet keine kostenlose Belieferung oder Eigentümer-Erstattung von Mieter-Netzstrom ab. Abrechnungskosten nur bei aktivem Verkauf. Rechtliche und messtechnische Voraussetzungen von §42b sind nicht geprüft. Bestehende gespeicherte Excel-Konfigurationen behalten ihren früheren aktivierten Verkauf als Standard.

Neue Datei profiles.js: zentrale Angebotsdaten, Hardware, Parameter, Anbieterreferenzen und Quellen. Für Nox einen weiteren eindeutigen Schlüssel mit derselben Struktur ergänzen; keine Werte erfinden. Der Auswahlknopf entsteht automatisch. Anbieterreferenzen werden nie zur Cashflow-Kalibrierung verwendet. JSON und lokale Speicherung enthalten offerId und tenantEnabled. Kein Nox-Profil ohne belegte Daten aktiviert.

Geänderte Dateien: index.html (Auswahl, Schalter, Ladefolge), app.js (Profilübernahme, Persistenz, getrennte Referenzen, Verkaufsschalter), dark.css (Profilanzeige), README.md. Neue Datei: profiles.js. property.js bleibt unverändert. Alle sechs Laufzeitdateien plus .nojekyll gemeinsam veröffentlichen.

Lokale Prüfung: JavaScript-Syntax und automatische Modelltests in work/test-offer.cjs. Excel-Basis bleibt bei aktivem Verkauf unverändert; geprüft wurden Profilübernahme, Erhalt bestehender WP-/Gaswerte, Migration, Export-Rundlauf, Schalter, 539-€-Annahme, entgangene Einspeisung, keine doppelte Bewertung, Energieerhaltung bei Null-/Niedrigertrag und verfügbare lokale Assets. In dieser Erweiterung keine erneute visuelle Browserprüfung und kein Live-Deployment ausgeführt.

## Korrektur Profilwechsel und gemeinsame Rechenbasis

Auf Übersicht: aktives Profil und aktuelle Parameter sichtbar, direkte Schnellauswahl. »Eigene Werte wiederherstellen« bringt die vor der Anbieterübernahme gespeicherten eigenen Energiekonfigurationen zurück. »Excel-Standardwerte laden« setzt bewusst die ursprünglichen Excel-Startwerte. Beide funktionieren auch nach Profilübernahme; die Auswahl Eigene Werte im Simulationsbereich kann nun ebenfalls übernommen werden. Der eigene Stand wird separat lokal gespeichert und mit exportiert. Vor Installation dieser Korrektur überschriebene eigene Werte sind ohne früheren Export nicht rekonstruierbar; bei Migration wird daher auf Excel-Standardwerte zurückgegriffen.

Szenariovergleich und Szenariowechsel behalten bei aktivem Angebot dessen aktuell eingestellten PV-Ertrag und Mieterstrom-Parameter. Andere Szenarioannahmen, etwa Deckungsquote eigen und Preissteigerungen, variieren weiterhin. Dashboard, Steuern, Jahresrechnung, PV-Verteilung und geplante Hausenergie greifen auf die aktuelle zentrale Konfiguration zu. Haus & Energie verwendet den aktuellen WP-Strombedarf der Simulation statt einer konkurrierenden JAZ-Schätzung. Die JAZ-Schätzung kann weiterhin bewusst als neuer Verbrauch übernommen werden. Historischer Gasverbrauch, Grundstück, Gebäudesubstanz und die unabhängige Wertspanne bleiben Hausdaten; ein Profilwechsel erzeugt keinen erfundenen zusätzlichen Immobilienaufschlag. Batterie-/SOC-Regler bleiben wie zuvor Betriebsvorgaben im Jahresmodell.

Lokale Prüfungen: work/test-offer.cjs und work/test-profile-ui.cjs. Zweiter Test führt die tatsächlichen Anwendungs-Ereignisfunktionen in einer simulierten DOM-Umgebung aus und prüft Schnellauswahl, geänderte KPI, Profilanzeige, Szenarioerhalt, Rückkehr zu eigenen Werten über beide Auswahlfelder, Standardwerte und Speicherstruktur. Keine erneute visuelle Browserprüfung oder Veröffentlichung.

## Separate Übersichten PV-Anlage und Wärmepumpe

Zwei zusätzliche Tabs verwenden denselben aktiven Profil- und Parameterstand wie das Gesamtdashboard. Beide zeigen Investition, Amortisation, grafischen kumulierten Saldo, Fünf-/Zehnjahres-Saldo, Energieübersicht und jährliche Detailrechnung.

Zuordnung ohne Doppelzählung: WP-Nutzen = vermiedener Gasbezug + Gasgrundpreis + Gaswartung minus gesamter WP-Strombedarf zum Bezugspreis minus WP-Wartung, zuzüglich WP-Förderung und V+V-Steuer. PV-Nutzen = eigene PV-Nutzung zum Bezugspreis + Einspeisung + Mieterstrom minus PV-Wartung und aktive Abrechnung, zuzüglich einmaligem PV-Steuereffekt. Die PV-Nutzung für die WP gehört damit zum PV-Nutzen. Beide Teilrechnungen addieren sich exakt zur Gesamtbilanz. Teil-Amortisationen hängen von dieser transparenten Zuordnung ab und sind keine unabhängig simulierten Angebote. Gas/Strom-Balken zeigen Energieträgereinsatz, nicht identischen Wärmebedarf.

Geändert: index.html, app.js, README.md. Lokale Prüfung: Syntax sowie test-offer.cjs, test-profile-ui.cjs und test-components.cjs. Summengleichheit für alle zehn Jahre und Nullertrag/Nullkosten/Null-WP geprüft. Keine visuelle Browserprüfung oder Veröffentlichung durchgeführt.

## PV-Erwartungen mit / ohne Wärmepumpe

Im PV-Tab zusätzlicher direkter Vergleich beider Fälle: identische Anlage, Kosten, PV-Erzeugung, Tarife und Mieterstromannahmen. Ohne WP wird ausschließlich der WP-Strombedarf auf null gesetzt und die PV-Verteilung neu berechnet. Die existierende Heizung bleibt bestehen. Ausgewiesen werden eigene Nutzung, Mietwohnung, Einspeisung, vermiedener Strombezug, Erlöse, PV-Nettonutzen, Fünf-/Zehnjahressaldo und PV-Amortisation. Nur die PV-Teilrechnung wird verglichen; WP-Investition, Gasersatz und WP-Förderung werden nicht als PV-Gewinn gerechnet. Wartung, Abrechnung und PV-Steuerwirkung bleiben berücksichtigt. Gleiche Jahresdeckungsquote in beiden Fällen ist eine Näherung, keine separate Stunden-/PV*SOL-Simulation.

Geändert: app.js und README.md. Prüfung: Syntax, bestehende Regressionen und work/test-pv-alternatives.cjs (gleicher PV-Ertrag/Investition, Energieerhaltung, Null-WP/Null-PV, Mieterschalter und Heidelberg-Profil). Keine neue visuelle Browserprüfung, kein Live-Deployment.

## Nox und Entscheidungshilfe — 10. Oktober 2026

Neuer Tab **Angebote & Entscheidung**: Leistungsgegenüberstellung, identische Rechenbasis, veränderbarer Score, offene Anbieterfragen und eigene nächste Schritte. Ein Profil kann hier oder auf der Übersicht aktiviert werden. Nox setzt die zentrale Simulation auf 31.220 €, 24,96 kWp, 24.960 kWh Jahresertrag und 18,072 kWh nutzbare Batterie. Letztere sind ausdrücklich eine 90-%-Annahme aus 20,08 kWh nominal; Herstellerbestätigung fehlt. Die optionale Wallbox ist nicht im Basispreis enthalten. Fehlende belastbare Nox-Autarkie und Amortisation erscheinen als unbekannt, nicht als null.

Quellen sind jetzt die geprüften Angebotsdateien: Nox ANG-2026-01218, Phase 2 vom 10.10.2026, Heidelberg AG5172 und aktuelle PV*SOL-Unterlagen. Die ältere Aussage, Heidelberg beruhe nur auf übermittelten Zahlen, ist damit überholt. Original-PDFs werden nicht veröffentlicht. Offene Nachweise sind keine behaupteten Produktmängel.

Beide Profile setzen zunächst **160 €/Jahr Messstellenkosten als gemeinsame Annahme**. Verbindliche Preise, Zusatzgeräte und Zähler fehlen. Das neue Feld im Tab Simulation ist editierbar; eigene gespeicherte Werte und ursprüngliche Excel-Standardwerte erhalten 0 €, damit der alte Excel-Abgleich unverändert bleibt. Messkosten gehören zur PV-Teilrechnung und zur Gesamtbilanz, ohne Doppelzählung.

Der Angebotsvergleich verwendet standardmäßig denselben vorsichtigen Ertrag von 24.960 kWh für beide Anlagen, dieselben aktiven Verbrauchs-/Tarif-/Steuer-/Förderparameter und gemeinsame Messkosten. WP kann separat ausgeschaltet werden. Alternativ sind Anbieter-Erträge auswählbar, deutlich als ungleiche Berechnungsgrundlagen markiert. Zusatzkosten pro Anbieter sind erfassbar. Diese Vergleichseinstellungen verändern die aktive Simulation nicht automatisch. Bei identischen Jahresannahmen beträgt der wirtschaftliche Unterschied zunächst nur 381 € Investition; das Modell beweist keinen Hardware- oder Speichervorteil, weil keine Stundenrechnung vorhanden ist.

Score: Preis 20 %, Planung 20 %, Integration 20 %, Garantie 15 %, Ersatzstrom 15 %, Vertragsklarheit 10 %. Gewichte werden auf ihre Summe normiert. Preisbewertung = günstigster Vergleichspreis / jeweiliger Vergleichspreis × 100; die anderen Startbewertungen sind offen begründete redaktionelle Einschätzungen des Dokumentationsstands. Anfangswerte ergeben Heidelberg 70,0 und Nox 50,8 von 100. Bewertungen, Gewichtungen und Begründungen sind frei anpassbar. Neue Antworten ändern den Score erst nach bewusster Neubewertung. Ein hoher Score ersetzt keine fehlenden Zusagen.

To-dos enthalten je Anbieter technische, messtechnische, Kosten-, Garantie- und Vertragspunkte sowie eigene Aufgaben zur Datenprüfung, Anbieteranfrage und Vertragsentscheidung. Status: offen, angefragt, Antwort erhalten, geprüft/erledigt, nicht erforderlich. Die letzten beiden verlangen einen Beleg beziehungsweise eine Begründung. Entscheidungsreife setzt alle als kritisch markierten Anbieter- und eigenen Aufgaben voraus; die Bestätigung erfolgt durch den Nutzer. Es werden keine Nachrichten versandt.

Notizen und Bewertungen werden lokal unter energy-optimizer.decision.v1 gespeichert. Der eigene Export im neuen Tab enthält Vergleichsrechnungen, Score und Aufgabenstand; der allgemeine JSON-Export enthält ebenfalls die Entscheidungseinstellungen. Browserwechsel erfordert einen Export als Dokumentation; ein automatischer Import des Entscheidungsstands ist derzeit nicht eingebaut.

Aktuelles vollständiges Pages-Paket: **index.html, app.js, profiles.js, property.js, decision.js, styles.css, dark.css, .nojekyll, README.md**. Frühere kürzere Dateilisten sind überholt. Diese Dateien gemeinsam ersetzen und committen; die lokale Änderung veröffentlicht sich nicht selbst auf GitHub Pages.

Prüfung dieser Erweiterung: Syntax aller vier JavaScript-Dateien; automatische Tests für Profilübernahme, Wiederherstellung eigener Werte, gemeinsame Rechenbasis, Teilrechnungssummen, PV mit/ohne WP, Nox-Annahmen, Vergleichskosten, Gewichte, Nachweispflicht und Speicherung. Tatsächliche Ereignisfunktionen wurden in einer simulierten DOM-Umgebung ausgeführt. Keine neue visuelle Browserprüfung und kein Live-Deployment durchgeführt.

## Sol-Living und Vergleich mit drei Anbietern — 30. Oktober 2026

Sol-Living ist als reguläres Profil in der Übersicht und in der Simulation verfügbar. Datenbasis: PV-Angebot 16.10.2026 und separates VREY-Angebot 13.10.2026. Heidelberg und Nox Phase 2 bleiben bestehen; der ältere Nox-Stand aus der eingefügten Auswertung wurde ausdrücklich nicht übernommen.

Sol-Living: 53 × AIKO 485 W, gerundet 25,71 kWp, FOX H3-Pro-25.0, EK12 Plus + EK6 Plus mit Junction Box, Smartfox Pro 3 und EPS Box Pro. 17,28 kWh sind angegeben, ihre Einordnung als nominal/nutzbar ist nicht eindeutig. Das Tool setzt vorsichtig 15,552 kWh nutzbar (90 %) als ausdrücklich unbestätigte Annahme an. Jahresertrag 27.304 kWh, Autarkie ca. 70 %, Eigenverbrauch ca. 37 % sind Anbieterreferenzen. Die behaupteten neun Jahre Amortisation sind wegen der enthaltenen Heizkosteneffekte kein direkt vergleichbarer PV-Nachweis und werden nicht zur Kalibrierung benutzt.

Regulärer Basispreis 38.464,41 €. 37.310,48 € nur bei vollständiger Vorkasse mindestens 14 Tage vorher. Standardprofil: ohne Vorkasse, ohne VREY, ohne optionale Versicherung, Mieterstrom aus; Verbrauchsbasis wie die anderen Angebote. 160 €/Jahr Messkosten ohne VREY sind weiterhin nur gemeinsame Planannahme. WP-Kosten, Tarife und Förder-/Steuerparameter stammen aus dem vorhandenen Projekt.

Im Entscheidungstab lassen sich Sol-Living-Pakete unabhängig schalten:

- VREY: 2.856 € einmalig brutto plus 734,11 €/Jahr brutto. Die einmaligen Kosten erhöhen die Vergleichsinvestition; das jährliche Paket ersetzt gemeinsame Messkosten und pauschale Mieterstrom-Abrechnung. Kein doppeltes Addieren von 160 € oder 180 €. Die gesamten VREY-Kosten werden nicht allein der Mietwohnung zugeschrieben. Der Verkaufsschalter bleibt eine unabhängige Annahme.
- Vorkasse: ausschließlich der bestätigte Skontopreis, mit deutlichem Hinweis auf das Vorleistungsrisiko. Dieser Schalter verbessert nicht automatisch die subjektive Vertragsbewertung.
- Optionale Versicherung: 8,99 €/Monat = 107,88 €/Jahr als separates Zusatzpaket. Bestehende Wartungs-/Versicherungsannahme bitte überprüfen, um Überschneidungen zu vermeiden.

VREY nennt vier Messstellen, kalkuliert aber fünf Aufnahmen/Datenanbindungen; drei Softwarelizenzen stehen zwei teilnehmenden Wohnungen gegenüber. Angebot bis 29.10.2026 gültig und an den Sol-Living-Ansprechpartner adressiert. Aktualisierter Endkundenpreis erforderlich. Installation der Messtechnik ist ausdrücklich ausgeschlossen. Zusätzliche 800 € für Mieterstromzähler und ggf. 1.400 € Zählerschrank werden nicht ungeprüft addiert; erst schriftlich abgrenzen und als Zusatzkosten erfassen. Auch ohne WP bleibt der angebotene VREY-Paketpreis bestehen, bis ein reduziertes Angebot vorliegt.

Ertragsbasis im Vergleich: gleiche absolute Erzeugung (Kostenszenario), gleicher spezifischer Ertrag je kWp (Basiswert / 24,96 × jeweilige kWp) oder jeweilige Anbieter-Erträge (ungleiche Quellen). Bei gleicher spezifischer Annahme bekommt Sol-Living entsprechend der größeren Anlage mehr Jahresertrag. Jahresmodell bleibt ohne Stundenlasten, saisonales Speichermodell oder berechneten Smartfox-Mehrnutzen.

Der Button „Vergleichswerte übernehmen“ überträgt die tatsächlich angezeigten Werte inklusive Paketen, Zusatzkosten, Ertrag und WP-Verbrauch in die zentrale Simulation. Alle Ansichten rechnen anschließend damit. Die normale Schnellauswahl lädt dagegen das reguläre Anbieterprofil. Wiederholte Übernahme addiert Pakete nicht erneut; Rückkehr zu anderen Profilen entfernt Sol-Living-Zusatzpakete, eigene Werte bleiben wiederherstellbar.

Vorläufiger Score bei regulärem Preis ohne Zusatzpakete: Heidelberg 70,0, Sol-Living 64,5, Nox 50,8. Kriterien/Gewichte unverändert; redaktionelle Einschätzung des schriftlichen Nachweisstands, keine empirische Produktqualitätsmessung. Neue Anbieterantworten und persönliche Prioritäten können die Reihenfolge ändern. Neun neue Sol-Living-Aufgaben enthalten Plan-/Ertragsnachweis, Speicherkompatibilität, Geräteintegration, Backup, SOL CARE, VREY-Mengen/Gültigkeit, vollständige Kosten, Zahlung/Abnahme und individuelles Messschema. Ohne kritische Nachweise bleibt auch ein Score-Favorit nicht entscheidungsreif.

Änderungen: profiles.js, app.js, decision.js, dark.css, README.md; zusätzliche Auswertung ANGEBOTSVERGLEICH.md. Bestehende gespeicherte Score-Gewichte, Bewertungen und Aufgaben werden um den dritten Anbieter ergänzt und bleiben erhalten.

Prüfung: sieben automatische Rechen-/Ereignistests, Syntax aller JS-Dateien und tatsächlicher Edge-Browsertest Desktop/390-px-Mobil. Profilwechsel, Übernahme der Paketkosten in zentrale Konfiguration, wiederholte Übernahme ohne Mehrfachkosten, Speicherung nach Neuladen, Wiederherstellung eigener Werte, drei Tabellenanbieter und fehlender horizontaler Seitenüberlauf geprüft. Desktop-/Mobilvorschau visuell geprüft. Kein GitHub-Commit und keine Veröffentlichung durchgeführt.

## Elektrotechnik Schütte — Ergänzung 02.11.2026

Viertes Profil „Elektrotechnik Schütte · 26.10.2026“, Grundlage Angebot V2609/6528-A, K2 Base „Oberst MA“ vom 16.10.2026, Fronius Reserva Pro und Axitec AXIperfect GQ WB. Quellen sind im Profil und bei zehn neuen Anbieter-To-dos angegeben. Original-PDFs werden nicht veröffentlicht.

Basis: 28.650,30 €, 39 × 460 W = **17,94 kWp**, vier Reserva-Pro-Batteriemodule = **15,9 kWh nutzbar** laut Datenblatt. Angebotsüberschrift 18,33 kWp und 19,8 kWh ist widersprüchlich: K2 plant 39 × 470 W = 18,33 kWp; 19,9 kWh nutzbar erfordern laut Datenblatt fünf Batteriemodule. Der Fronius-Hybridwechselrichter ist nur mit 20 kW, nicht mit konkreter Baureihe benannt. Keine pauschale Gleichsetzung mit einer bestimmten Fronius-Baureihe.

K2 Base ist Montage-/Statikplanung und keine Ertragsrechnung. Anbieter-Jahresertrag, Autarkie, Einspeisung und Amortisation bleiben unbekannt. Für das Rechenmodell nur als Annahme: 1.000 kWh/kWp → 17.940 kWh/Jahr. Mieterstrom startet aus; Messkosten 160 €/Jahr bleiben unbestätigte gemeinsame Planannahme. WP-Kosten, Tarife und Steuern/Förderung bleiben aus der zentralen Simulation.

Vergleichsoptionen: 70 Solardachziegel × 42 € = 2.940 € Eventualposition; bei Aktivierung 31.590,30 € Vergleichsinvestition. 470-W-Variante aus K2 separat zuschaltbar: 18,33 kWp, bei 1.000 kWh/kWp 18.330 kWh/Jahr. Unveränderter Basispreis in dieser Variante ist eine unbestätigte Preisannahme und ausdrücklich so markiert. Gerüst sowie sonstige unbekannte Nebenarbeiten weiterhin nicht als kostenlos ansehen; nach verbindlicher Bezifferung als Zusatzkosten eintragen. Wiederholte Übernahme addiert Dachziegel nicht mehrfach.

Vier Anbieter verwenden dynamische Tabellenüberschriften und vier Score-Karten. Neu ausgewiesen: Leistung und Investition je kWp. Für frische Entscheidungsstände wird „gleicher spezifischer Ertrag je kWp“ vorausgewählt; gespeicherte Ertragsmodi bleiben erhalten. Gleiche absolute Erzeugung ist bei der kleineren Schütte-Anlage nur ein künstliches Kostenszenario. Im Modus Anbieter-Erträge bleibt Schütte mangels Nachweis bei ausdrücklich gekennzeichneter 1.000-kWh/kWp-Annahme.

Preiskriterium des bisherigen Scores bewertet weiterhin das absolute Budget und nicht €/kWp; darauf weist die Oberfläche hin. Redaktionelle Kriterien für die drei bisherigen Anbieter bleiben unverändert. Wegen des niedrigeren Basispreises ändert sich aber ihr relativer Preisanteil: Startwerte ohne Zusatzoptionen Heidelberg 68,6, Sol-Living 63,4, Nox 49,4, Schütte 49,3. Keine real gemessene Produktqualitätsrangliste. Bei aktivierten Dachziegeln oder Zusatzkosten ändern sich auch diese Werte. Alte Gewichte, persönliche Bewertungen und Aufgabenstatus werden übernommen.

Offene Themen Schütte: eindeutige Module und Speichermenge, objektspezifischer Ertrag, Carport-/25-kWp-Alternative, K2-Randbedingungen und Gebäudeverifizierung, Gerüst/Ziegel/Schrank/Überspannungsschutz, §42b-Messung, konkrete WP-/Wallbox-/§14a-Integration, Backup-Leistung, Service-/Austauschkosten sowie 80/10/10-Zahlungsplan und verbindlicher Endpreis. Genereller Überspannungsschutz-Ausschluss steht neben angebotener DC-ÜS-Box; Leistungsabgrenzung klären.

Dateien: profiles.js, app.js, decision.js, dark.css, README.md und ANGEBOTSVERGLEICH.md. Tests im Projekt unter work/test-schuette.cjs, aktualisierte generische Vergleichstests und fortgeführter Sol-Living-Test. Acht automatische Rechen-/Ereignistests und Syntaxprüfung aller vier JavaScript-Dateien bestanden. Edge-Test für Desktop und 390-px-Mobil mit vier Profilen/fünf Tabellenspalten, fehlenden Anbieterreferenzen, beiden Schütte-Optionen, zentraler Übernahme, mehrfacher Übernahme, Aufgaben-/Optionsspeicherung, Profilwechseln und ohne JavaScript-Fehler oder horizontalen Seitenüberlauf. Screenshots visuell geprüft. Kein GitHub-Commit oder Live-Deployment durchgeführt.

## Regeln & Risiken — 02.11.2026

Neuer Tab mit vier ausdrücklich hypothetischen Fällen: bisherige Rechnung, nur Netzaufschlag, Übergang & Marktannahme, Stress ohne späteren Einspeiseerlös. Quellenlinks führen zu offiziellem AgNes-Verfahren/-Entwurf und Bundestagsinformation zum EEG-Gesetzentwurf; keine automatische Einordnung nach Inbetriebnahme-Recht, Bestandsschutz oder 25-kW-Schwelle. Die voreingestellten Werte sind Sensitivitätsannahmen, keine Rechts-/Preisprognose.

- Bisherige Rechnung: unveränderter konstanter feedTariff, keine neuen Risikokosten.
- Nur Netzaufschlag: unveränderter feedTariff für die zehn Modelljahre; zusätzlich 100 €/Jahr je eingestellter Marktlokation ab Kalenderjahr 2029.
- Übergang & Marktannahme: drei volle Betriebsjahre 5,2 ct/kWh, danach 3 ct/kWh vor 120 €/Jahr Vermarktungskosten; zusätzlich 100 €/Marktlokation/Jahr ab 2029.
- Stress: drei Jahre 5,2 ct/kWh, danach 0 ct/kWh vor 180 €/Jahr Vermarktungskosten; 150 €/Marktlokation/Jahr ab 2029. Absichtlich ungünstige Annahme, kein prognostizierter Marktverlauf.

Alle Parameter sind editierbar. Erstes volles Betriebsjahr voreingestellt 2027, Marktlokationen eine; keine anteilige Kalenderjahresrechnung. Jahr i erhält Kalenderjahr commissioningYear+i-1. Wechsel der Einspeisephase nach transitionYears vollen Betriebsjahren; bei null sofort Marktannahme. Netzaufschlag separat ab prosumerStartYear: prosumerAnnual × prosumerLocations. Nach erster Einspeisephase fällt marketingCost als fixe Jahrespauschale an, auch bei Einspeisung null. Durchschnittspreis darf negativ sein; keine Stunden-/Negativpreis-Prognose. Kein automatisches weiteres Einspeiseentgelt oder Speicherentgelt.

Zusätzliche regulatorische Kosten sind PV-Projektkosten. Sie erscheinen in Gesamtbilanz und PV-Teilrechnung einmalig je Jahr; PV plus WP addieren sich weiterhin exakt. Einspeiseerlös = Einspeisemenge × Tarif der jeweiligen Phase. Gebühren sind separat und nicht nochmals vom kWh-Tarif abgezogen. Bestehende VREY-, Mess-/Abrechnungs- und Wartungskosten bleiben bestehen; falls Vermarktungs-/Netzleistungen später bereits in einem Paket enthalten sind, entsprechenden Zusatzansatz selbst auf null setzen. Ein möglicher Umbau allgemeiner Bezugstarife wird nicht automatisch prognostiziert; aktuelle Strom-/Gaspreise bleiben Eingaben.

Der neue Tab zeigt vier Szenariokarten mit Übernahmeknöpfen, aktiven Stand, Delta gegen unveränderte Referenz, Gesamtsalden nach fünf/zehn Jahren, PV-Saldo, Amortisation, grafischen Verlauf sowie jährliche Kalenderjahre, Tarife und Gebühren. Übersicht zeigt die aktive Risikoannahme. Übernahme aktualisiert alle zentralen Ansichten sowie den wirtschaftlichen Angebotsvergleich. Anbieter-Hardware und -Referenzen sowie der subjektive Dokumentationsscore ändern sich nicht. Profilwechsel erhalten Risikoannahmen; Szenarien Konservativ/Basis/Optimistisch verändern diese neuen Parameter nicht. Rückkehr zu eigenen Werten beziehungsweise Excel-Standard stellt den jeweiligen gespeicherten/bewusst gewählten Stand wieder her.

GGV-/Mieter-/WP-Teilnahme ändert die Zahl der Marktlokationen nicht automatisch. Zähleranzahl und Marktlokationen sind nicht identisch. Für andere Messkonzepte Werte bewusst ändern. Alle vier Angebote nutzen die gemeinsam eingestellte Zahl; Anbieter mit verschiedenen Messkonzepten zusätzlich in getrennten Konfigurationen rechnen/exportieren.

Alte gespeicherte Konfigurationen erhalten regulationEnabled=0 und behalten den bisherigen Cashflow. Neue Felder sind in zentraler Speicherung und beiden allgemeinen JSON-Exporten enthalten. Der Download enthält jetzt ebenfalls den Entscheidungsstand. Keine automatische Umstellung auf einen vermeintlich beschlossenen Gesetzesstand.

Geändert: app.js, index.html, decision.js, dark.css, README.md; neu regulation.js. Veröffentlichungspaket jetzt elf Dateien inklusive regulation.js. Alle zusammen ersetzen. Bestehende Angebotsanalyse bleibt erhalten; keine Original-PDFs enthalten.

Prüfung: neun automatische Rechen-/Ereignistests, JavaScript-Syntaxprüfung sowie Edge auf Desktop/390-px-Mobil. Jahresgrenzen 2026/2027/2030, Marktlokationen 0/2, 1.600-€-Zehnjahresdelta beim Start 2027 für 2 × 100 € ab 2029, sofortiger/verspäteter Tarifwechsel, negative Tarifannahme, Gebührenzuordnung, PV-/WP-Summengleichheit, alle Anbieter, eigene Eingaben, Speicherung/Neuladen, zentrale KPI und Rückkehr zur bisherigen Rechnung geprüft. Screenshots visuell geprüft. Kein GitHub-Commit oder Live-Deployment durchgeführt.
